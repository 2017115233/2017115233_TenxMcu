#include<reg52.h>

#ifndef __DISPLAY_H__
#define __DISPLAY_H__

void Init_Timer0(void);

#endif
