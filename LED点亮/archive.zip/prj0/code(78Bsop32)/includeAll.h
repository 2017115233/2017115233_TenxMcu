#include <REGtenxTM52F5278B.h>

#include "display.h"
#include "init.h"
#include "main.h"
#include "typeAlias.h"
